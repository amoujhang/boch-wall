// ==UserScript==
// @name         blocknewtab
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  blocknewtab
// @match        http://*/*
// @grant        none
// @include      *
// ==/UserScript==

var start = 0;
var inactivityTime = function () {
    var time;
    var count = 0;

    window.onload = resetTimer;
    document.onmousemove = resetTimer;
    document.onkeypress = resetTimer;
    document.onload = resetTimer;
    document.onmousemove = resetTimer;
    document.onmousedown = resetTimer; // touchscreen presses
    document.ontouchstart = resetTimer;
    document.onclick = resetTimer;// touchpad clicks
    document.onscroll = resetTimer;// scrolling with arrow keys
    document.onkeypress = resetTimer;


    function update(){
        console.log('now time='+window.start);
        if(window.self === window.top){
            window.start += 1000;
            if(window.start >= 600000){
                logout();
            }
            setTimeout(update, 1000)
            if(!window.location.href.includes("http://127.0.0.1:8080/sinica")){
                logout();
            }
        }
    }
    function logout() {
        window.start = 0
        console.log("You are now logged out."+window.location.href)
        if(window.location.href != 'http://127.0.0.1:8080/boch/public.html'){
            window.location.href = 'http://127.0.0.1:8080/boch/public.html'
        }
    }

    function resetTimer() {
        //clearTimeout(time);
        //time = setTimeout(logout, 10000)
        window.start = 0;
        var anchors = document.getElementsByTagName("a");
        for (var i = 0; i < anchors.length; i++) {
            anchors[i].target = "_self"
        }
        anchors = document.getElementsByTagName("form");
        for (i = 0; i < anchors.length; i++) {
            anchors[i].target = "_self"
        }
        console.log("target reseted.");
    }
    //setTimeout(update, 1000)
};
inactivityTime();

