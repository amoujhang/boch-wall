// ==UserScript==
// @name         Tampermonkey for Private Boch
// @namespace    http://tampermonkey.net/
// @version      0.1
// @require      http://ajax.googleapis.com/ajax/libs/jquery/2.0.0/jquery.js
// @require      https://unpkg.com/mqtt/dist/mqtt.min.js
// @description  try to take over the world!
// @author       You
// @match        http://192.168.2.100:8080/boch/private.html
// @grant        none
// ==/UserScript==

var clientwss = mqtt.connect('wss://13share.me:1885', {username:'devicemgr',password:'mqtt@13techart'})
clientwss.on('connect', function () {
    console.log('mqttwss connected')
	clientwss.subscribe('boch/wall/private/#', function (err) {
		if (err) {

		} else {
			console.log('mqttwss boch/wall/private/# subscribed.')
		}
	})
})
clientwss.on("message", function (topic, message) {
    if(topic == 'boch/wall/private/open') {
        var index = parseInt(JSON.parse(message).key) + 1;
        var elements = document.getElementsByClassName(`inner-btn${index}`)
        if(elements!=null && elements.length>0){
            document.getElementsByClassName(`inner-btn${index}`)[0].click();
        }
    }
    console.log(`Wss Received topic=${topic} message=${message.toString()}`)
})