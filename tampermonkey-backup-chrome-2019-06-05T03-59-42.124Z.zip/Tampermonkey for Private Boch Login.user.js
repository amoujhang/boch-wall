// ==UserScript==
// @name         Tampermonkey for Private Boch Login
// @namespace    http://tampermonkey.net/
// @version      0.1
// @require      http://ajax.googleapis.com/ajax/libs/jquery/2.0.0/jquery.js
// @require      https://unpkg.com/mqtt/dist/mqtt.min.js
// @include      https://monitor.boch.gov.tw/*
// @include      http://www.cy-tech.com/*
// @include      https://eocdss1.ncdr.nat.gov.tw/*
// @include      https://eocdss.ncdr.nat.gov.tw/*
// @include      http://eocdss.ncdr.nat.gov.tw/web/*
// @include      https://aims.boch.gov.tw/*
// @grant        GM.xmlHttpRequest
// ==/UserScript==

var clientwss = mqtt.connect('wss://13share.me:1885', {username:'devicemgr',password:'mqtt@13techart'})
clientwss.on('connect', function () {
    console.log('mqttwss connected')
	clientwss.subscribe('boch/wall/private/#', function (err) {
		if (err) {

		} else {
			console.log('mqttwss boch/wall/private/# subscribed.')
		}
	})
})
clientwss.on("message", function (topic, payload) {

    if(topic == 'boch/wall/private/login'){
        var obj = JSON.parse(payload)
        var key = obj.key
        var username = obj.username
        var password = obj.password
        var code = obj.code
        if(key == '0'){
            var els=document.getElementsByName("tb_Account");
            for (var i=0;i<els.length;i++) {
                els[i].value = username;
            }
            els=document.getElementsByName("tb_au4a83");
            for (i=0;i<els.length;i++) {
                els[i].value = password;
            }
            els=document.getElementsByName("txt_input");
            for (i=0;i<els.length;i++) {
                els[i].value = code;
            }
            console.log(username+','+password+','+code)
            document.getElementById("btn_login").click();
        }
        else if(key == '1'){
            els=document.getElementById("txtAccount");
            els.value = username;
            els=document.getElementById("txtPassword");
            els.value = password;
            els=document.getElementById("txtCaptcha");
            els.value = code;
            console.log(username+','+password+','+code)
            GM.xmlHttpRequest({
                method: "POST",
                url: "https://eocdss.ncdr.nat.gov.tw/web/GetData/Portal/getSysEntry.ashx",
                data:'Acc='+username+'&Pwd='+password+'&vcode='+code,
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                onload: function(data) {
                    var res = JSON.parse(data.responseText)
                    console.log(res)
                    if (typeof (res.error) != "undefined") {
                        alert(res.error);
                        return
                    }
                    if (res.sysEntry[0].EntryId == 0) {
                        window.location.href = 'http://eocdss.ncdr.nat.gov.tw/web/'
                    } else {
                        window.location.href = 'http://eocdss.ncdr.nat.gov.tw/web/'
                    }
                }
            });
        } else if(key == '2'){
            els=document.getElementsByName("txtUSERNAME");
            for (i=0;i<els.length;i++) {
                els[i].value = username;
            }
            els=document.getElementsByName("txtPASSWORD");
            for (i=0;i<els.length;i++) {
                els[i].value = password;
            }
            els=document.getElementsByName("txtCheckCode");
            for (i=0;i<els.length;i++) {
                els[i].value = code;
            }
            console.log(username+','+password+','+code)
            document.getElementById("lbtIn").click();
        } else if(key == '3'){
            els=document.getElementsByName("tb_Account");
            for (i=0;i<els.length;i++) {
                els[i].value = username;
            }
            els=document.getElementsByName("tb_au4a83");
            for (i=0;i<els.length;i++) {
                els[i].value = password;
            }
            els=document.getElementsByName("txt_input");
            for (i=0;i<els.length;i++) {
                els[i].value = code;
            }
            console.log(username+','+password+','+code)
            document.getElementById("btn_login").click();
        }
    }
    if(topic == 'boch/wall/private/logout'){
        obj = JSON.parse(payload)
        key = obj.key

        if(key == '0'){
            document.getElementById("lbtn_logout").click();
        }
        if(key == '1'){
            document.getElementById("aLogout").click();
            window.location.href = "https://eocdss.ncdr.nat.gov.tw/web/ucPortal/login.html"
        }
        if(key == '2'){
            document.getElementById("hlkLoginout").click();
        }
        if(key == '3'){
            document.getElementById("lbtn_logout").click();
        }
    }
})
/*
client.subscribe("mqtt/boch-demo")
client.on("message", function (topic, payload) {
    //switchObjDisplay('divLogin')
    var obj = JSON.parse(payload)
    var username = obj.username
    var password = obj.password
    var code = obj.code
    var els=document.getElementById("txtAccount");
    els.value = username;
    els=document.getElementById("txtPassword");
    els.value = password;
    els=document.getElementById("txtCaptcha");
    els.value = code;
    console.log(username+','+password+','+code)
    //document.getElementById("btnLogin").click();
    GM.xmlHttpRequest({
        method: "POST",
        url: "https://eocdss.ncdr.nat.gov.tw/web/GetData/Portal/getSysEntry.ashx",
        data:'Acc='+username+'&Pwd='+password+'&vcode='+code,
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        },
        onload: function(data) {
            var res = JSON.parse(data.responseText)
            console.log(res)
            if (typeof (res.error) != "undefined") {
                alert(res.error);
                return
            }
            if (res.sysEntry[0].EntryId == 0) {
                //window.postMessage(res.sysEntry[0].EntryUrl + "|" + res.sysEntry[0].EntryId
                //                          + "|" + res.sysEntry[0].EntryName + "|ncdrlogin", '*');
                //window.close();
                window.location.href = 'http://eocdss.ncdr.nat.gov.tw/web/'
            } else {
                //var obj = window.opener;
                //傳送的message中新增ncdrlogin，用來識別是災情網登入後傳送的message
                //window.postMessage(res.sysEntry[0].EntryUrl + "|ncdrlogin", '*');
                //window.close();
                window.location.href = 'http://eocdss.ncdr.nat.gov.tw/web/'
            }
        }
    });
})
*/

/*
var client = mqtt.connect('wss://13share.me:1885', {username:'devicemgr',password:'mqtt@13techart'})
client.subscribe("mqtt/boch-demo")
client.on("message", function (topic, payload) {
    var obj = JSON.parse(payload)
    var username = obj.username
    var password = obj.password
    var code = obj.code
    var els=document.getElementsByName("tb_Account");
    for (var i=0;i<els.length;i++) {
        els[i].value = username;
    }
    els=document.getElementsByName("tb_au4a83");
    for (i=0;i<els.length;i++) {
        els[i].value = password;
    }
    els=document.getElementsByName("txt_input");
    for (i=0;i<els.length;i++) {
        els[i].value = code;
    }
    console.log(username+','+password+','+code)
    document.getElementById("btn_login").click();
})
*/
/*
var client = mqtt.connect('wss://13share.me:1885', {username:'devicemgr',password:'mqtt@13techart'})
client.subscribe("mqtt/boch-demo")
client.on("message", function (topic, payload) {
    var obj = JSON.parse(payload)
    var username = obj.username
    var password = obj.password
    var code = obj.code
    var els=document.getElementsByName("txtUSERNAME");
    for (var i=0;i<els.length;i++) {
        els[i].value = username;
    }
    els=document.getElementsByName("txtPASSWORD");
    for (i=0;i<els.length;i++) {
        els[i].value = password;
    }
    els=document.getElementsByName("txtCheckCode");
    for (i=0;i<els.length;i++) {
        els[i].value = code;
    }
    console.log(username+','+password+','+code)
    document.getElementById("lbtIn").click();
})
*/